# portfolio-tutorial-html-CSS-JS
Code and assets for a beginner-friendly YouTube tutorial on building a responsive portfolio with HTML, CSS, and JavaScript. Share your YouTube thumbnails for community feedback. Let's learn, code, and create together! 
